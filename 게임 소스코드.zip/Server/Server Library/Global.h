#pragma once
extern class SessionMGR* GSessionMGR;
extern class IOCP* GIOCP;
extern class ThreadMGR* GThreadMGR;

