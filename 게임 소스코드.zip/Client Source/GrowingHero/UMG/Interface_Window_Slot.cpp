// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface_Window_Slot.h"

// Add default functionality here for any IInterface_Window_Slot functions that are not pure virtual.
